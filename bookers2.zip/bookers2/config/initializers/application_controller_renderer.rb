# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '09c0927a59e6a71ee2212c5364345a0624b0641b9ff15f43557e63c20ca37a0c91c29cb30ce9ce0248e584c0a0f76d964c462f4adbb6f3342fa1a584b7177e07'